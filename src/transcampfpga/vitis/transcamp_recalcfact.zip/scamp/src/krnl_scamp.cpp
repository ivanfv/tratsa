/**********
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********/

/*******************************************************************************
Description: 
    This is the SCAMP kernel implementation using C++ HLS
*******************************************************************************/
#include "cpfp.hpp"
#include "scamp.h"
#include <cstring>
#include "ap_int.h"
#include <iostream>


const unsigned int vector_data_size  = VDATA_SIZE;
const unsigned int array_partition 	 = ARRAY_PARTITION;
const unsigned int loop_unrolling 	 = LOOP_UNROLLING;
const unsigned int wide_buff_size    = (VDATA_SIZE / (MEM_WIDTH / FLOAT_BITS));
const unsigned int general_buff_size = (VDATA_SIZE / (MEM_WIDTH / FLOAT_BITS)) + 1;


void adjust_offset_cpfp(ap_int<MEM_WIDTH> * in, cpfp * out, unsigned offset)
{
	unsigned index = 0;
	adjust_offset_l1:for(int j = offset; j < 16; j++)
	{
		#pragma HLS PIPELINE II=1
		out[index] = in[0].range((j + 1) * FLOAT_BITS - 1, j  % 16 * FLOAT_BITS);
		index++;
	}
	adjust_offset_l2:for (int i = 1; i < 32; i++)
	{
		#pragma HLS PIPELINE II=1
		for(int j = 0; j < 16; j++)
		{
			#pragma HLS unroll factor=loop_unrolling
			out[index] = in[i].range((j + 1) * FLOAT_BITS - 1, j  % 16 * FLOAT_BITS);
			index++;
		}
	}
	adjust_offset_l3:for(int j = 0; j < offset; j++)
	{
		#pragma HLS PIPELINE II=1
		out[index] = in[32].range((j + 1) * FLOAT_BITS - 1, j  % 16 * FLOAT_BITS);
		index++;
	}
}


void calculate_covariances(ITYPE i, ITYPE j, const ap_int<MEM_WIDTH> * tSeries, ap_int<MEM_WIDTH> * tmp_tSeries_i, cpfp * tmp_covariances, const ap_int<MEM_WIDTH> * means, ap_int<MEM_WIDTH> * buff_A,
			cpfp * tmp_means_j, cpfp * tmp_tSeries_j, ITYPE windowSize)
{
	ITYPE j_offset = j % 16;
	ITYPE i_read_counter = i % 16;


	// Initialization of covariances to 0
	for (int k = 0; k < VDATA_SIZE / 2; k++)
	{
		#pragma HLS PIPELINE II=1
		tmp_covariances[k] = float2cpfp(0);
		tmp_covariances[k + VDATA_SIZE / 2] = float2cpfp(0);
	}

	// Burst read of means for current set of diagonals
	memcpy(buff_A, &means[j / 16], 2112);
	adjust_offset_cpfp(buff_A,  tmp_means_j, j_offset);

	cpfp means_i = uint32(means[i / 16].range((i % 16 + 1) * FLOAT_BITS - 1, (i % 16) * FLOAT_BITS));


	// Copy first time series data
	memcpy(buff_A, &(tSeries[j / 16]), 2112);

	memcpy(tmp_tSeries_i, &tSeries[(i) / 16], sizeof(DTYPE) * VDATA_SIZE);


	// Calculate first covariances for this set of diagonals
	first_cov_main:for (ITYPE w = 0; w < windowSize; w++)
	{

		j_offset = (j + w) % 16;

		if(j_offset == 0)
			memcpy(buff_A, &(tSeries[(j + w) / 16]), 2112);

		adjust_offset_cpfp(buff_A,  tmp_tSeries_j, j_offset);

		// if i_read_counter reached VDATA_SIZE update buffer
		if(i_read_counter == VDATA_SIZE)
		{
			i_read_counter = 0;
			memcpy(tmp_tSeries_i, &tSeries[(w + i) / 16], sizeof(DTYPE) * VDATA_SIZE);
		}

		cpfp tSeries_i_value = uint32(tmp_tSeries_i[i_read_counter / 16].range((i_read_counter % 16 + 1) * FLOAT_BITS - 1, i_read_counter % 16 * FLOAT_BITS));

		first_cov_calc:for (int k = 0; k < VDATA_SIZE; k++)
		{
			#pragma HLS PIPELINE II=1
			#pragma HLS unroll factor=loop_unrolling
			tmp_covariances[k] += (tmp_tSeries_j[k] - tmp_means_j[k]) * (tSeries_i_value - means_i);
		}
		i_read_counter++;
	}

}


extern "C" {
void krnl_scamp(const ap_int<MEM_WIDTH> *tSeries, // tSeries input
				const ap_int<MEM_WIDTH> *means,	  // Means input
				const ap_int<MEM_WIDTH> *df,	  // df input
				const ap_int<MEM_WIDTH> *dg,	  // dg input
				const ap_int<MEM_WIDTH> *norms,	  // Norms input
				uint32_t *profile,				  // Profile input
				ITYPE *profileIndex,		      // ProfileIndex input
				const ITYPE profileLength,	      // profileLength
				const ITYPE startDiag,	          // First Diagonal
				const ITYPE endDiag,	          // Last Diagonal
				const ITYPE windowSize,		      // windowSize
				const ITYPE recalc_cov		      // windowSize
) {
	/* -------------------------------- INTERFACES CONFIGURATION --------------------------------------- */
	#pragma HLS INTERFACE m_axi port = tSeries      offset = slave bundle = gmem0 max_read_burst_length=64
	#pragma HLS INTERFACE m_axi port = means        offset = slave bundle = gmem0 max_read_burst_length=64
	#pragma HLS INTERFACE m_axi port = df           offset = slave bundle = gmem0 max_read_burst_length=64
	#pragma HLS INTERFACE m_axi port = dg           offset = slave bundle = gmem1 max_read_burst_length=64
	#pragma HLS INTERFACE m_axi port = norms        offset = slave bundle = gmem0 max_read_burst_length=64
	#pragma HLS INTERFACE m_axi port = profile      offset = slave bundle = gmem2 max_read_burst_length=64
	#pragma HLS INTERFACE m_axi port = profileIndex offset = slave bundle = gmem2 max_read_burst_length=64

	#pragma HLS INTERFACE s_axilite port = tSeries       bundle = control
	#pragma HLS INTERFACE s_axilite port = means         bundle = control
	#pragma HLS INTERFACE s_axilite port = df            bundle = control
	#pragma HLS INTERFACE s_axilite port = dg            bundle = control
	#pragma HLS INTERFACE s_axilite port = norms         bundle = control
	#pragma HLS INTERFACE s_axilite port = profile       bundle = control
	#pragma HLS INTERFACE s_axilite port = profileIndex  bundle = control
	#pragma HLS INTERFACE s_axilite port = profileLength bundle = control
	#pragma HLS INTERFACE s_axilite port = startDiag     bundle = control
	#pragma HLS INTERFACE s_axilite port = endDiag       bundle = control
	#pragma HLS INTERFACE s_axilite port = windowSize    bundle = control
	#pragma HLS INTERFACE s_axilite port = return        bundle = control
	/* ------------------------------------------------------------------------------------------------- */

	// General purpose buffers
	ap_int<MEM_WIDTH> buff_A[general_buff_size];
	ap_int<MEM_WIDTH> buff_B[general_buff_size];
	ap_int<MEM_WIDTH> buff_C[general_buff_size];
	ap_int<MEM_WIDTH> buff_D[general_buff_size];

	// Time series temporal buffers
	ap_int<MEM_WIDTH> tmp_tSeries_i[wide_buff_size];
	cpfp              tmp_tSeries_j[VDATA_SIZE];

	// Means temporal buffers
	//cpfp means_0;
	cpfp tmp_means_j[VDATA_SIZE];

	// df temporal buffers
	ap_int<MEM_WIDTH> tmp_df_i[VDATA_SIZE];
	cpfp tmp_df_j            [VDATA_SIZE];

	// dg temporal buffers
	ap_int<MEM_WIDTH> tmp_dg_i[VDATA_SIZE];
	cpfp tmp_dg_j            [VDATA_SIZE];

	// profile temporal buffers
	cpfp tmp_profile_j[VDATA_SIZE];

	// profileIndex temporal buffers
	ITYPE tmp_profileIndex_i[VDATA_SIZE];
	ITYPE tmp_profileIndex_j[VDATA_SIZE];

	// Covariances temporal buffer
	cpfp tmp_covariances [VDATA_SIZE];

	// Correlations temporal buffer
	cpfp tmp_correlations[VDATA_SIZE];

	// imax temporal buffer
	cpfp  tmp_i_max      [loop_unrolling];
	ITYPE tmp_i_index_max[loop_unrolling];

	// Auxiliary variables
	ITYPE i, j;
	ITYPE num_covs;
	unsigned i_read_counter;
	unsigned j_offset;
	//unsigned index;

	/* ------------------------ ARRAY PARTITION POLICY ----------------------------- */
	#pragma HLS array_partition variable=tmp_tSeries_j      cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_means_j        cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_df_j           cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_dg_j           cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_covariances    cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_correlations   cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_profile_j 	    cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_profileIndex_j cyclic factor=array_partition
	#pragma HLS array_partition variable=tmp_i_max 	        complete
	#pragma HLS array_partition variable=tmp_i_index_max    complete
	/* ----------------------------------------------------------------------------- */


	// Main loop: go through diagonals
	main_loop: for(ITYPE diag = startDiag; diag < endDiag; diag += VDATA_SIZE)
	{
		// Initialize diagonal coordinates
		i = 0;
		num_covs = 1;
		j = diag;

		calculate_covariances(i, j, tSeries, tmp_tSeries_i, tmp_covariances, means, buff_A,
					tmp_means_j, tmp_tSeries_j, windowSize);


		i_read_counter = VDATA_SIZE - 1;

		// Initialize buffers
		memcpy(buff_A, &df   [j / 16], 2112);
		memcpy(buff_B, &dg   [j / 16], 2112);
		memcpy(buff_C, &norms[j / 16], 2112);


		for(int k = 0; k < VDATA_SIZE; k++)
		{
			#pragma HLS pipeline II=1
			tmp_profile_j[k] = profile[j + k];
 		}

		for(int k = 0; k < VDATA_SIZE; k++)
		{
			#pragma HLS pipeline II=1
			tmp_profileIndex_j[k] = profileIndex[j + k];
 		}

		diag:for (j = diag; j < profileLength; j++)
		{
			i_read_counter++;

			if(i_read_counter == VDATA_SIZE)
			{
				i_read_counter = 0;

				memcpy(tmp_tSeries_i, &norms[i / 16], sizeof(DTYPE) * VDATA_SIZE);

				{
					#pragma HLS loop_merge
					memcpy(tmp_df_i,      &df[i / 16],    sizeof(DTYPE) * VDATA_SIZE);
					memcpy(tmp_dg_i,      &dg[i / 16],    sizeof(DTYPE) * VDATA_SIZE);
				}
			}

			// Calculate j offset
			j_offset = j % 16;

			// Read norms if necessary
			if(j_offset == 0)
			{
			  memcpy(buff_C, &norms[j / 16], 2112);
			}

			adjust_offset_cpfp(buff_C,  tmp_means_j, j_offset);

			// Obtain norm value for i index
			cpfp norms_i_value = uint32(tmp_tSeries_i[i_read_counter / 16].range((i_read_counter % 16 + 1) * FLOAT_BITS - 1, i_read_counter % 16 * FLOAT_BITS));

			// Calculate correlations
			correlations:for (int k = 0; k < VDATA_SIZE; k++)
			{
				#pragma HLS unroll factor=loop_unrolling
				#pragma HLS pipeline II=1
				tmp_correlations[k] = tmp_covariances[k] * norms_i_value * tmp_means_j[k];
			}

			// Obtain df and dg values for i index
			cpfp df_i_value = uint32(tmp_df_i[i_read_counter / 16].range((i_read_counter % 16 + 1) * FLOAT_BITS - 1, i_read_counter % 16 * FLOAT_BITS));
			cpfp dg_i_value = uint32(tmp_dg_i[i_read_counter / 16].range((i_read_counter % 16 + 1) * FLOAT_BITS - 1, i_read_counter % 16 * FLOAT_BITS));

			// Read df and dg if necessary
			if(j_offset == 0)
			{
				#pragma HLS loop_merge
				memcpy(buff_A, &df[j / 16], 2112);
				memcpy(buff_B, &dg[j / 16], 2112);
			}

			// Update covariances
			if(num_covs < recalc_cov)
			{
				// Adjust offset of df and dg
				adjust_offset_cpfp(buff_A,  tmp_df_j, j_offset);
				adjust_offset_cpfp(buff_B,  tmp_dg_j, j_offset);

				covariances_update:for(int k = 0; k < VDATA_SIZE; k++)
				{
					#pragma HLS unroll factor=loop_unrolling
					#pragma HLS pipeline II=1
					tmp_covariances[k] += (df_i_value * tmp_dg_j[k]) + (tmp_df_j[k] * dg_i_value);
				}
				num_covs++;
			}
			else
			{
				calculate_covariances(i + 1, j + 1, tSeries, tmp_tSeries_i, tmp_covariances, means, buff_A,
							tmp_means_j, tmp_tSeries_j, windowSize);

				memcpy(tmp_tSeries_i, &norms[i / 16], sizeof(DTYPE) * VDATA_SIZE);
				memcpy(buff_A, &df[j / 16], 2112);
				num_covs = 0;

			}


			// Discard out-of-bound values
			if(j + VDATA_SIZE > profileLength)
			{
				unsigned num_preserve = profileLength - j;
				discard_loop:for(int k = num_preserve; k < VDATA_SIZE; k++)
				{
					#pragma HLS pipeline II=1
					tmp_correlations[k] = float2cpfp(-1);
				}
			}

			// Init max i values to -1
			init_i_updates:for(int k = 0; k < 16; k++)
			{
				#pragma HLS pipeline II=1
				tmp_i_max[k] = float2cpfp(-1);
			}

			// Calculate both i and j updates
			calculate_updates:for (int k = 0; k < VDATA_SIZE; k += loop_unrolling)
			{
				#pragma HLS pipeline II=2

				for(int kk = 0; kk < loop_unrolling; kk++)
				{
					#pragma HLS unroll
					if(tmp_correlations[k + kk] > tmp_i_max[kk]){
						tmp_i_max[kk] = tmp_correlations[k + kk];
						tmp_i_index_max[kk] = j + k + kk;
					}

					if (tmp_correlations[k + kk] > tmp_profile_j[k + kk])
					{
						tmp_profile_j[k + kk] = tmp_correlations[k + kk];
						tmp_profileIndex_j[k + kk] = i;
					}
				}
			}

			// Update profile j and profileIndex j
			profile[j]      = (uint32_t) tmp_profile_j[0];
			profileIndex[j] = tmp_profileIndex_j[0];

			// shift temp profile j one to the left
			shift_profile_j:for(int i =0; i < VDATA_SIZE - 1; i++)
			{
				#pragma HLS unroll
				tmp_profile_j[i] = tmp_profile_j[i + 1];
			}

			// shift temp profileIndex j one to the left
			shift_profileIndex_j:for(int i =0; i < VDATA_SIZE - 1; i++)
			{
				#pragma HLS unroll
				tmp_profileIndex_j[i] = tmp_profileIndex_j[i + 1];

			}

			// Get new element for temp profile j and temp profileIndex j
			tmp_profile_j[VDATA_SIZE - 1]      = (cpfp) profile[j + VDATA_SIZE];
			tmp_profileIndex_j[VDATA_SIZE - 1] = profileIndex[j + VDATA_SIZE];


			calculate_i_updates:for(int k = 0; k<loop_unrolling; k++)
			{
				#pragma HLS pipeline II=2
				if(tmp_i_max[k] > tmp_i_max[0])
				{
					tmp_i_max[0]       = tmp_i_max[k];
					tmp_i_index_max[0] = tmp_i_index_max[k];
				}

			}

			// Update profile i if necessary
			if(tmp_i_max[0] > (cpfp) profile[i])
			{
				profile[i] = (uint32_t) tmp_i_max[0];
				profileIndex[i] = tmp_i_index_max[0];
			}
			i++;
		}
	}
}
}

