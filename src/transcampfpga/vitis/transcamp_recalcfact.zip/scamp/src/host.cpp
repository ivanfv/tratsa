/**********
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
**********/

/*******************************************************************************
Description:
    This is the SCAMP host implementation using C++ HLS
*******************************************************************************/
#include "cpfp.hpp"
#include "xcl2.hpp"
#include "scamp.h"
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sstream>
#include <cmath>
#include <limits>
#include <math.h>
#include <vector>

#define ENABLE_DEBUG false

using namespace std;

//Number of HBM Banks required
#define MAX_HBM_BANKCOUNT 30
#define BANK_NAME(n) n | XCL_MEM_TOPOLOGY
const int bank[MAX_HBM_BANKCOUNT] = {
    BANK_NAME(0),  BANK_NAME(1),  BANK_NAME(2),  BANK_NAME(3),  BANK_NAME(4),
    BANK_NAME(5),  BANK_NAME(6),  BANK_NAME(7),  BANK_NAME(8),  BANK_NAME(9),
    BANK_NAME(10), BANK_NAME(11), BANK_NAME(12), BANK_NAME(13), BANK_NAME(14),
    BANK_NAME(15), BANK_NAME(16), BANK_NAME(17), BANK_NAME(18), BANK_NAME(19),
    BANK_NAME(20), BANK_NAME(21), BANK_NAME(22), BANK_NAME(23), BANK_NAME(24),
    BANK_NAME(25), BANK_NAME(26), BANK_NAME(27), BANK_NAME(28), BANK_NAME(29)};

void preprocess(std::vector<double> &tSeries,
				std::vector<uint32, aligned_allocator<uint32>> &means,
				std::vector<uint32, aligned_allocator<uint32>> &norms,
				std::vector<uint32, aligned_allocator<uint32>> &df,
				std::vector<uint32, aligned_allocator<uint32>> &dg,
				ITYPE profileLength, ITYPE windowSize)
{
	std::vector<double, aligned_allocator<double>> prefix_sum		(tSeries.size());
	std::vector<double, aligned_allocator<double>> prefix_sum_sq	(tSeries.size());

	std::vector<double, aligned_allocator<double>> means_aux	(tSeries.size());
	std::vector<double, aligned_allocator<double>> norms_aux	(tSeries.size());

	  // Calculates prefix sum and square sum vectors
	  prefix_sum [0] = tSeries[0];
	  prefix_sum_sq [0] = tSeries[0] * tSeries[0];
	  for (ITYPE i = 1; i < tSeries.size(); ++i)
	  {
		prefix_sum[i]    = tSeries[i] + prefix_sum[i - 1];
		prefix_sum_sq[i] = tSeries[i] * tSeries[i] + prefix_sum_sq[i - 1];
	  }

	  // Prefix sum value is used to calculate mean value of a given window, taking last value
	  // of the window minus the first one and dividing by window size
	  means_aux[0] = prefix_sum[windowSize - 1] / static_cast<double> (windowSize);
	  for (ITYPE i = 1; i < profileLength; ++i)
	  {
		means_aux[i] = (prefix_sum[i + windowSize - 1] - prefix_sum[i - 1]) / static_cast<double> (windowSize);
	  }
	  for (ITYPE i = 0; i < profileLength; ++i)
	  {
		means[i] = float2cpfp(means_aux[i]);
	  }

	  double sum = 0;
	  for (ITYPE i = 0; i < windowSize; ++i)
	  {
		DTYPE val = tSeries[i] - means_aux[0];
		sum += val * val;
	  }
	  norms_aux[0] = sum;

	  // Calculates L2-norms (euclidean norm, euclidean distance)
	  for (ITYPE i = 1; i < profileLength; ++i)
	  {
		norms_aux[i] = norms_aux[i - 1] + ((tSeries[i - 1] - means_aux[i - 1]) + (tSeries[i + windowSize - 1] - means_aux[i])) *
				(tSeries[i + windowSize - 1] - tSeries[i - 1]);
	  }
	  for (ITYPE i = 0; i < profileLength; ++i)
	  {
		norms[i] = float2cpfp((float)(1.0 / sqrt(norms_aux[i])));
	  }

	  // Calculates df and dg vectors
	  for (ITYPE i = 0; i < profileLength - 1; ++i) {
		df[i] = float2cpfp((float)((tSeries[i + windowSize] - tSeries[i]) / 2.0));
		dg[i] = float2cpfp((float)(tSeries[i + windowSize] - means_aux[i + 1]) + (tSeries[i] - means_aux[i]));
	  }
}

void scamp_host(std::vector<uint32, aligned_allocator<uint32>> &tSeries,
				std::vector<uint32, aligned_allocator<uint32>> &means,
				std::vector<uint32, aligned_allocator<uint32>> &norms,
				std::vector<uint32, aligned_allocator<uint32>> &df,
				std::vector<uint32, aligned_allocator<uint32>> &dg,
				std::vector<uint32, aligned_allocator<uint32>> &profile,
				std::vector<ITYPE, aligned_allocator<ITYPE>> &profileIndex,
				ITYPE profileLength, ITYPE exclusionZone, ITYPE windowSize)
{
	   cpfp covariance, correlation;
	   // Go through diagonals
	   for (ITYPE diag = exclusionZone + 1; diag < profileLength; diag++)
	  // for (ITYPE diag = exclusionZone + 1; diag < exclusionZone + 2; diag++)
	   {
		   //if((diag - (exclusionZone+1)) % 50 == 0)
		   //std::cout << "DONE: " <<  (float)(diag - (exclusionZone+1)) / (profileLength - (exclusionZone + 1)) * 100 << "%" << std::endl;

		   covariance = (cpfp) 0;

		   ITYPE i = 0;
		   ITYPE num_covs = 0;

		   for (ITYPE w = 0; w < windowSize; w++)
		   {
			   covariance += (((cpfp) tSeries[diag + w] - (cpfp) means[diag]) * ((cpfp) tSeries[w] - (cpfp) means[0]));
		   }
		   //std::cout << cpfp2float(covariance) << std::endl;

		   correlation = covariance * (cpfp) norms[0] * (cpfp) norms[diag];


	       if(correlation > (cpfp) profile[i])
	       {
	    	   profile[i]      = correlation;
	    	   profileIndex[i] = diag;
	       }

	       if(correlation > (cpfp) profile[diag])
	       {
	    	   profile[diag]      = correlation;
	    	   profileIndex[diag] = i;
	       }

	       i++;
	       num_covs++;
	       for (ITYPE j = diag + 1; j < profileLength; j++)
	       {
	    	   if(num_covs < 65536)
	    	   {
	    		   covariance += (((cpfp) df[i-1] * (cpfp) dg[j-1]) + ((cpfp) df[j-1] * (cpfp) dg[i-1]));

			       num_covs++;

	    	   }
	    	   else
	    	   {
	    		  /// std::cout << "prenew " <<cpfp2float(covariance) << std::endl;
	    		   covariance = (cpfp) 0;
	    		   for (ITYPE w = 0; w < windowSize; w++)
	    		   {
	    			   covariance += (((cpfp) tSeries[j + w] - (cpfp) means[j]) * ((cpfp) tSeries[w + i] - (cpfp) means[i]));
	    		   }
	    		   num_covs=0;
					//std::cout << " new " <<cpfp2float(covariance) << std::endl;

	    	   }

	    	   correlation = covariance * (cpfp) norms[i] * (cpfp) norms[j];
		       //std::cout << num_covs<<" corrr " <<cpfp2float(correlation)<<std::endl ;

	    	   if(correlation > (cpfp) profile[i])
	    	   {
	    		   profile[i] = correlation;
	    		   profileIndex[i] = j;
	    	   }

	    	   if(correlation > (cpfp) profile[j])
	    	   {
	    		   profile[j] = correlation;
	    		   profileIndex[j] = i;
	    	   }
	    	   i++;
	      }
	    }
}

// Function for verifying results
bool verify(std::vector<uint32, aligned_allocator<uint32>> &source_sw_profile,
            std::vector<uint32, aligned_allocator<uint32>> &source_hw_profile,
			std::vector<ITYPE, aligned_allocator<ITYPE>> &source_sw_profileIdxs,
			std::vector<ITYPE, aligned_allocator<ITYPE>> &source_hw_profileIdxs,
            unsigned int size) {
    bool check = true;

    for (size_t i = 0; i < size; i++) {
        if (source_hw_profile[i] != source_sw_profile[i]) {
            std::cout << "Error: Profile result mismatch" << std::endl;
            std::cout << "i = " << i << " CPU result = " << cpfp2float(source_sw_profile[i])
                      << " Device result = " << cpfp2float(source_hw_profile[i])
                      << std::endl;
            check = false;
        }
       if (source_hw_profileIdxs[i] != source_sw_profileIdxs[i]) {
            std::cout << "Error: Profile Idxs result mismatch" << std::endl;
            std::cout << "i = " << i << " CPU result = " << source_sw_profileIdxs[i]
                      << " Device result = " << source_hw_profileIdxs[i]
                      << std::endl;
            check = false;
        }
    }
    return check;
}

double run_krnls(cl::Context &context,
                cl::CommandQueue &q,
                std::vector<cl::Kernel> &kernels,
                std::vector<uint32, aligned_allocator<uint32>> &source_tSeries,
                std::vector<uint32, aligned_allocator<uint32>> &source_means,
				std::vector<uint32, aligned_allocator<uint32>> &source_norms,
				std::vector<uint32, aligned_allocator<uint32>> &source_df,
				std::vector<uint32, aligned_allocator<uint32>> &source_dg,
                std::vector<uint32, aligned_allocator<uint32>> &source_hw_profile,
				std::vector<ITYPE, aligned_allocator<ITYPE>> &source_hw_profileIndex,
                const int *bank_assign,
                ITYPE size,
				ITYPE profileLength, ITYPE exclusionZone, ITYPE windowSize) {
    cl_int err;

    // Temporal profile and profileIndex
    std::vector<uint32, aligned_allocator<uint32>> profile_tmp_0    	(size + VDATA_SIZE);
    std::vector<uint32, aligned_allocator<uint32>> profile_tmp_1    	(size + VDATA_SIZE);
    std::vector<uint32, aligned_allocator<uint32>> profile_tmp_2    	(size + VDATA_SIZE);
    std::vector<uint32, aligned_allocator<uint32>> profile_tmp_3    	(size + VDATA_SIZE);
    std::vector<uint32, aligned_allocator<uint32>> profile_tmp_4    	(size + VDATA_SIZE);
    std::vector<uint32, aligned_allocator<uint32>> profile_tmp_5    	(size + VDATA_SIZE);
    std::vector<ITYPE, aligned_allocator<ITYPE>> profileIndex_tmp_0	(size + VDATA_SIZE);
    std::vector<ITYPE, aligned_allocator<ITYPE>> profileIndex_tmp_1	(size + VDATA_SIZE);
    std::vector<ITYPE, aligned_allocator<ITYPE>> profileIndex_tmp_2	(size + VDATA_SIZE);
    std::vector<ITYPE, aligned_allocator<ITYPE>> profileIndex_tmp_3	(size + VDATA_SIZE);
    std::vector<ITYPE, aligned_allocator<ITYPE>> profileIndex_tmp_4	(size + VDATA_SIZE);
    std::vector<ITYPE, aligned_allocator<ITYPE>> profileIndex_tmp_5	(size + VDATA_SIZE);

    // Temporal profiles initialization
    for(ITYPE i = 0; i < size; i++)
    {
    	profile_tmp_0[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
    	profile_tmp_1[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
    	profile_tmp_2[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
    	profile_tmp_3[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
    	profile_tmp_4[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
    	profile_tmp_5[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());

    	profileIndex_tmp_0[i] = 0;
    	profileIndex_tmp_1[i] = 0;
    	profileIndex_tmp_2[i] = 0;
    	profileIndex_tmp_3[i] = 0;
    	profileIndex_tmp_4[i] = 0;
    	profileIndex_tmp_5[i] = 0;
    }

    // Static Scheduling
    ITYPE startDiags[NUM_KERNELS];
    ITYPE endDiags  [NUM_KERNELS];

    ITYPE kernel_diag_start = exclusionZone + 1;
    float factor = 1.75;
    ITYPE kernel_diag_end = exclusionZone + 1 + (profileLength / (NUM_KERNELS * factor));

    for (unsigned k = 0; k < NUM_KERNELS - 1; k++)
    {
    	startDiags[k] = kernel_diag_start;
    	endDiags[k]   = kernel_diag_end;

    	kernel_diag_start = kernel_diag_end + 1;
    	kernel_diag_end += (profileLength / (NUM_KERNELS * factor));

    	factor-=0.25;
    }

	startDiags[NUM_KERNELS - 1] = kernel_diag_start;
    endDiags[NUM_KERNELS - 1]   = profileLength;

    for (unsigned k = 0; k < NUM_KERNELS; k++)
    {
    	std::cout << "[INFO] Kernel " << k << " start: " << startDiags[k] << " end: " << endDiags[k] << std::endl;
    }

    cout << "[HOST] Creating buffers...";

    // For Allocating Buffer to specific Global Memory Bank, user has to use cl_mem_ext_ptr_t
    // and provide the Banks
    cl_mem_ext_ptr_t inBuffersExt[22];
    cl_mem_ext_ptr_t inOutBuffersExt[16];

    // Read-only buffers parameters
    unsigned index = 0;

    // In buffers HBM[0]
    for(unsigned i = 0; i < 11; i++)
    {
    		inBuffersExt[index].param = 0;
    		inBuffersExt[index].flags = bank[i];
    		index++;
    }

    // In buffers HBM[1]
    for(unsigned i = 15; i < 26; i++)
    {
    		inBuffersExt[index].param = 0;
    		inBuffersExt[index].flags = bank[i];
    		index++;
    }

    inBuffersExt[0].obj  = source_tSeries.data();
    inBuffersExt[1].obj  = source_means.data();
    inBuffersExt[2].obj  = source_df.data();
    inBuffersExt[3].obj  = source_dg.data();
    inBuffersExt[4].obj  = source_norms.data();
    inBuffersExt[5].obj  = source_df.data();
    inBuffersExt[6].obj  = source_dg.data();
    inBuffersExt[7].obj  = source_norms.data();
    inBuffersExt[8].obj  = source_df.data();
    inBuffersExt[9].obj  = source_dg.data();
    inBuffersExt[10].obj = source_norms.data();
    inBuffersExt[11].obj = source_tSeries.data();
    inBuffersExt[12].obj = source_means.data();
    inBuffersExt[13].obj = source_df.data();
    inBuffersExt[14].obj = source_dg.data();
    inBuffersExt[15].obj = source_norms.data();
    inBuffersExt[16].obj = source_df.data();
    inBuffersExt[17].obj = source_dg.data();
    inBuffersExt[18].obj = source_norms.data();
    inBuffersExt[19].obj = source_df.data();
    inBuffersExt[20].obj = source_dg.data();
    inBuffersExt[21].obj = source_norms.data();

	// Read-only buffers create
	cl::Buffer buffers_input[22];

	for(unsigned i = 0; i < 22; i++)
	{
		buffers_input[i] = cl::Buffer (context, CL_MEM_READ_ONLY |
									   CL_MEM_EXT_PTR_XILINX | CL_MEM_USE_HOST_PTR,
									   sizeof(uint32) * (size + VDATA_SIZE), &inBuffersExt[i], &err);
	}

    // Read-Write buffers parameters
    index = 0;

    // Inout buffers HBM[0]
    for(unsigned i = 11; i < 14; i++)
    {
    		inOutBuffersExt[index].param = 0;
    		inOutBuffersExt[index].flags = bank[i];

    		inOutBuffersExt[index + 1].param = 0;
    		inOutBuffersExt[index + 1].flags = bank[i];
			index+=2;
    }

    // Inout buffers HBM[1]
    for(unsigned i = 26; i < 29; i++)
    {
    		inOutBuffersExt[index].param = 0;
    		inOutBuffersExt[index].flags = bank[i];

       		inOutBuffersExt[index + 1].param = 0;
       		inOutBuffersExt[index + 1].flags = bank[i];

			index+=2;
    }

    inOutBuffersExt[0].obj  = profile_tmp_0.data();
	inOutBuffersExt[1].obj  = profileIndex_tmp_0.data();
	inOutBuffersExt[2].obj  = profile_tmp_1.data();
	inOutBuffersExt[3].obj  = profileIndex_tmp_1.data();
    inOutBuffersExt[4].obj  = profile_tmp_2.data();
	inOutBuffersExt[5].obj  = profileIndex_tmp_2.data();
	inOutBuffersExt[6].obj  = profile_tmp_3.data();
	inOutBuffersExt[7].obj  = profileIndex_tmp_3.data();
	inOutBuffersExt[8].obj  = profile_tmp_4.data();
	inOutBuffersExt[9].obj  = profileIndex_tmp_4.data();
	inOutBuffersExt[10].obj = profile_tmp_5.data();
	inOutBuffersExt[11].obj = profileIndex_tmp_5.data();

	// Read-Write buffers create
	cl::Buffer buffers_inout[12];

	for(unsigned i = 0; i < 12; i++)
	{
			buffers_inout[i] = cl::Buffer (context,	 CL_MEM_READ_WRITE |
													 CL_MEM_EXT_PTR_XILINX |
													 CL_MEM_USE_HOST_PTR,
													 sizeof(uint32) * (size + VDATA_SIZE),
													 &inOutBuffersExt[i],
													 &err);
	}

    cout << "OK." << endl;

    ITYPE recalc_covs = 65536;

    // Setting arguments for Kernel 0
    OCL_CHECK(err, err = (kernels[0]).setArg(0, buffers_input[0])); // tSeries_i
    OCL_CHECK(err, err = (kernels[0]).setArg(1, buffers_input[1])); // means
    OCL_CHECK(err, err = (kernels[0]).setArg(2, buffers_input[2])); // df
    OCL_CHECK(err, err = (kernels[0]).setArg(3, buffers_input[3])); // dg
    OCL_CHECK(err, err = (kernels[0]).setArg(4, buffers_input[4])); // norms
    OCL_CHECK(err, err = (kernels[0]).setArg(5, buffers_inout[0])); // profile
    OCL_CHECK(err, err = (kernels[0]).setArg(6, buffers_inout[1])); // profileIndex
    OCL_CHECK(err, err = (kernels[0]).setArg(7, profileLength));	// profileLength
    OCL_CHECK(err, err = (kernels[0]).setArg(8, startDiags[0])); 	// startDiag
    OCL_CHECK(err, err = (kernels[0]).setArg(9, endDiags[0]));	    // endDiag
    OCL_CHECK(err, err = (kernels[0]).setArg(10, windowSize));		// windowSize
    OCL_CHECK(err, err = (kernels[0]).setArg(11, recalc_covs));		// recalc_covs

    // Setting arguments for Kernel 1
    OCL_CHECK(err, err = (kernels[1]).setArg(0, buffers_input[0])); // tSeries_i
    OCL_CHECK(err, err = (kernels[1]).setArg(1, buffers_input[1])); // means
    OCL_CHECK(err, err = (kernels[1]).setArg(2, buffers_input[5])); // df
    OCL_CHECK(err, err = (kernels[1]).setArg(3, buffers_input[6])); // dg
    OCL_CHECK(err, err = (kernels[1]).setArg(4, buffers_input[7])); // norms
    OCL_CHECK(err, err = (kernels[1]).setArg(5, buffers_inout[2])); // profile
    OCL_CHECK(err, err = (kernels[1]).setArg(6, buffers_inout[3])); // profileIndex
    OCL_CHECK(err, err = (kernels[1]).setArg(7, profileLength));	// profileLength
    OCL_CHECK(err, err = (kernels[1]).setArg(8, startDiags[1])); 	// startDiag
    OCL_CHECK(err, err = (kernels[1]).setArg(9, endDiags[1]));	    // endDiag
    OCL_CHECK(err, err = (kernels[1]).setArg(10, windowSize));		// windowSize
    OCL_CHECK(err, err = (kernels[1]).setArg(11, recalc_covs));		// recalc_covs


    // Setting arguments for Kernel 2
    OCL_CHECK(err, err = (kernels[2]).setArg(0, buffers_input[0])); // tSeries_i
    OCL_CHECK(err, err = (kernels[2]).setArg(1, buffers_input[1])); // means
    OCL_CHECK(err, err = (kernels[2]).setArg(2, buffers_input[8])); // df
    OCL_CHECK(err, err = (kernels[2]).setArg(3, buffers_input[9])); // dg
    OCL_CHECK(err, err = (kernels[2]).setArg(4, buffers_input[10]));// norms
    OCL_CHECK(err, err = (kernels[2]).setArg(5, buffers_inout[4])); // profile
    OCL_CHECK(err, err = (kernels[2]).setArg(6, buffers_inout[5])); // profileIndex
    OCL_CHECK(err, err = (kernels[2]).setArg(7, profileLength));	// profileLength
    OCL_CHECK(err, err = (kernels[2]).setArg(8, startDiags[2])); 	// startDiag
    OCL_CHECK(err, err = (kernels[2]).setArg(9, endDiags[2]));	    // endDiag
    OCL_CHECK(err, err = (kernels[2]).setArg(10, windowSize));		// windowSize
    OCL_CHECK(err, err = (kernels[2]).setArg(11, recalc_covs));		// recalc_covs


    // Setting arguments for Kernel 3
    OCL_CHECK(err, err = (kernels[3]).setArg(0, buffers_input[11])); // tSeries_i
    OCL_CHECK(err, err = (kernels[3]).setArg(1, buffers_input[12])); // means
    OCL_CHECK(err, err = (kernels[3]).setArg(2, buffers_input[13])); // df
    OCL_CHECK(err, err = (kernels[3]).setArg(3, buffers_input[14])); // dg
    OCL_CHECK(err, err = (kernels[3]).setArg(4, buffers_input[15])); // norms
    OCL_CHECK(err, err = (kernels[3]).setArg(5, buffers_inout[6]));  // profile
    OCL_CHECK(err, err = (kernels[3]).setArg(6, buffers_inout[7]));  // profileIndex
    OCL_CHECK(err, err = (kernels[3]).setArg(7, profileLength));	 // profileLength
    OCL_CHECK(err, err = (kernels[3]).setArg(8, startDiags[3])); 	 // startDiag
    OCL_CHECK(err, err = (kernels[3]).setArg(9, endDiags[3]));	     // endDiag
    OCL_CHECK(err, err = (kernels[3]).setArg(10, windowSize));		 // windowSize
    OCL_CHECK(err, err = (kernels[3]).setArg(11, recalc_covs));		// recalc_covs


    // Setting arguments for Kernel 4
    OCL_CHECK(err, err = (kernels[4]).setArg(0, buffers_input[11])); // tSeries_i
    OCL_CHECK(err, err = (kernels[4]).setArg(1, buffers_input[12])); // means
    OCL_CHECK(err, err = (kernels[4]).setArg(2, buffers_input[16])); // df
    OCL_CHECK(err, err = (kernels[4]).setArg(3, buffers_input[17])); // dg
    OCL_CHECK(err, err = (kernels[4]).setArg(4, buffers_input[18])); // norms
    OCL_CHECK(err, err = (kernels[4]).setArg(5, buffers_inout[8]));  // profile
    OCL_CHECK(err, err = (kernels[4]).setArg(6, buffers_inout[9]));  // profileIndex
    OCL_CHECK(err, err = (kernels[4]).setArg(7, profileLength));	 // profileLength
    OCL_CHECK(err, err = (kernels[4]).setArg(8, startDiags[4])); 	 // startDiag
    OCL_CHECK(err, err = (kernels[4]).setArg(9, endDiags[4]));	     // endDiag
    OCL_CHECK(err, err = (kernels[4]).setArg(10, windowSize));		 // windowSize
    OCL_CHECK(err, err = (kernels[4]).setArg(11, recalc_covs));		// recalc_covs


    // Setting arguments for Kernel 5
    OCL_CHECK(err, err = (kernels[5]).setArg(0, buffers_input[11])); // tSeries_i
    OCL_CHECK(err, err = (kernels[5]).setArg(1, buffers_input[12])); // means
    OCL_CHECK(err, err = (kernels[5]).setArg(2, buffers_input[19])); // df
    OCL_CHECK(err, err = (kernels[5]).setArg(3, buffers_input[20])); // dg
    OCL_CHECK(err, err = (kernels[5]).setArg(4, buffers_input[21])); // norms
    OCL_CHECK(err, err = (kernels[5]).setArg(5, buffers_inout[10])); // profile
    OCL_CHECK(err, err = (kernels[5]).setArg(6, buffers_inout[11])); // profileIndex
    OCL_CHECK(err, err = (kernels[5]).setArg(7, profileLength));	 // profileLength
    OCL_CHECK(err, err = (kernels[5]).setArg(8, startDiags[5])); 	 // startDiag
    OCL_CHECK(err, err = (kernels[5]).setArg(9, endDiags[5]));	     // endDiag
    OCL_CHECK(err, err = (kernels[5]).setArg(10, windowSize));		 // windowSize
    OCL_CHECK(err, err = (kernels[5]).setArg(11, recalc_covs));		// recalc_covs


    // Copy input data to Device Global Memory
    cout << "[HOST] Copying data to device...";
	for(unsigned i = 0; i < 22; i++)
	{
	    OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffers_input[i]}, 0));
	}

	for(unsigned i = 0; i < 12; i++)
	{
	    OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffers_inout[i]}, 0));
	}

    q.finish();
    cout << "OK." << endl;

    cout << "[FPGA] Running SCAMP kernel..." << endl;
    std::chrono::duration<double> kernel_time(0);
    auto kernel_start = std::chrono::high_resolution_clock::now();
    OCL_CHECK(err, err = q.enqueueTask(kernels[0]));
    OCL_CHECK(err, err = q.enqueueTask(kernels[1]));
    OCL_CHECK(err, err = q.enqueueTask(kernels[2]));
    OCL_CHECK(err, err = q.enqueueTask(kernels[3]));
    OCL_CHECK(err, err = q.enqueueTask(kernels[4]));
    OCL_CHECK(err, err = q.enqueueTask(kernels[5]));
    q.finish();
    auto kernel_end = std::chrono::high_resolution_clock::now();
    kernel_time = std::chrono::duration<double>(kernel_end - kernel_start);

    // Copy Result from Device Global Memory to Host Local Memory
    cout << "[HOST] Copying data from device...";
	for(unsigned i = 0; i < 12; i++)
	{
	    OCL_CHECK(err, err = q.enqueueMigrateMemObjects({buffers_inout[i]},
	            		  	  	  	  	  	  CL_MIGRATE_MEM_OBJECT_HOST));
	}
    q.finish();
    cout << "OK." << endl;

    cout << "[HOST] Reducing profile...";

    // Profile reduction
    for(ITYPE i = 0; i < profileLength; i++)
    {
    	//std::cout << cpfp2float(profile_tmp_0[i]) << std::endl;
    	if ((cpfp) profile_tmp_0[i] > (cpfp) source_hw_profile[i])
    	{
    		source_hw_profile[i] = profile_tmp_0[i];
    		source_hw_profileIndex[i] = profileIndex_tmp_0[i];
    	}
    	if ((cpfp) profile_tmp_1[i] > (cpfp) source_hw_profile[i])
    	{
    		source_hw_profile[i] = profile_tmp_1[i];
    		source_hw_profileIndex[i] = profileIndex_tmp_1[i];
    	}
    	if ((cpfp) profile_tmp_2[i] > (cpfp) source_hw_profile[i])
    	{
    		source_hw_profile[i] = profile_tmp_2[i];
    		source_hw_profileIndex[i] = profileIndex_tmp_2[i];
    	}
    	if ((cpfp) profile_tmp_3[i] > (cpfp) source_hw_profile[i])
    	{
    		source_hw_profile[i] = profile_tmp_3[i];
    		source_hw_profileIndex[i] = profileIndex_tmp_3[i];
    	}
    	if ((cpfp) profile_tmp_4[i] > (cpfp) source_hw_profile[i])
    	{
    		source_hw_profile[i] = profile_tmp_4[i];
    		source_hw_profileIndex[i] = profileIndex_tmp_4[i];
    	}
    	if ((cpfp) profile_tmp_5[i] > (cpfp) source_hw_profile[i])
    	{
    		source_hw_profile[i]      = profile_tmp_5[i];
    		source_hw_profileIndex[i] = profileIndex_tmp_5[i];
    	}
    }
    cout << "OK." << endl;
    return kernel_time.count();
}

int main(int argc, char *argv[]) {

    if (argc != 5) {
        printf("Usage: %s <XCLBIN> <TSERIES_INPUT> <WINDOW_SIZE>\n", argv[0]);
        return -1;
    }
    cl_int err;
    cl::Context context;
    cl::CommandQueue q;
    std::vector<cl::Kernel> kernels(NUM_KERNELS);
    std::string binaryFile = argv[1];
    std::string kernel_name = "krnl_scamp";
    bool debug = ENABLE_DEBUG;


    // Display wellcome through console
    std::cout << std::endl;
    std::cout << "############################################################" << std::endl;
    std::cout << "/////////////////////// SCAMP FPGA /////////////////////////" << std::endl;
    std::cout << "############################################################" << std::endl;

    // The get_xil_devices will return vector of Xilinx Devices
    auto devices = xcl::get_xil_devices();

    // read_binary_file() command will find the OpenCL binary file created using the
    // V++ compiler load into OpenCL Binary and return pointer to file buffer.
    auto fileBuf = xcl::read_binary_file(binaryFile);

    cl::Program::Binaries bins{{fileBuf.data(), fileBuf.size()}};
    int valid_device = 0;
    for (unsigned int i = 0; i < devices.size(); i++) {
        auto device = devices[i];
        // Creating Context and Command Queue for selected Device
        OCL_CHECK(err, context = cl::Context({device}, NULL, NULL, NULL, &err));
        OCL_CHECK(err,
                  q = cl::CommandQueue(
                      context, {device}, CL_QUEUE_PROFILING_ENABLE | CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE, &err));

        std::cout << "[HOST] Trying to program device[" << i
                  << "]: " << device.getInfo<CL_DEVICE_NAME>() << std::endl;
        cl::Program program(context, {device}, bins, NULL, &err);
        if (err != CL_SUCCESS) {
            std::cout << "[HOST] Failed to program device[" << i
                      << "] with xclbin file!\n";
        } else {
            std::cout << "[HOST] Device[" << i << "]: program successful!\n";
            for(int k = 0; k < NUM_KERNELS; k++)
            {
            	std::string s = kernel_name+":{"+kernel_name + "_" + to_string(k+1)+"}";
            	OCL_CHECK(err,
            			kernels[k] = cl::Kernel(program, s.c_str(), &err));
            }
            valid_device++;
            break; // we break because we found a valid device
        }
    }
    if (valid_device == 0) {
        std::cout << "[HOST] Failed to program any device found, exit!\n";
        exit(EXIT_FAILURE);
    }

    std::vector<double> ts_aux;
    std::fstream timeSeriesFile(argv[2], std::ios_base::in);
  	double tempval;
  	ITYPE timeSeriesLength = 0;
  	while (timeSeriesFile >> tempval)
  	{
  		ts_aux.push_back(tempval);
  		timeSeriesLength++;
  	}
  	timeSeriesFile.close();

    unsigned int dataSize = ts_aux.size();
    /*if (xcl::is_emulation()) {
        dataSize = 2048;
        std::cout << "Original Dataset is reduced for faster execution on "
                     "emulation flow. Data size=" << dataSize << std::endl;
    }*/

    std::vector<uint32, aligned_allocator<uint32>> source_tSeries       	(dataSize + 512);
    std::vector<uint32, aligned_allocator<uint32>> source_means         	(dataSize + 512);
    std::vector<uint32, aligned_allocator<uint32>> source_norms        	 	(dataSize + 512);
    std::vector<uint32, aligned_allocator<uint32>> source_df	        	(dataSize + 512);
    std::vector<uint32, aligned_allocator<uint32>> source_dg	        	(dataSize + 512);
    std::vector<uint32, aligned_allocator<uint32>> source_hw_profile    	(dataSize + 512);
    std::vector<ITYPE,  aligned_allocator<ITYPE>>  source_hw_profileIndex	(dataSize + 512);
    std::vector<uint32, aligned_allocator<uint32>> source_sw_profile    	(dataSize);
    std::vector<ITYPE,  aligned_allocator<ITYPE>>  source_sw_profileIndex	(dataSize);

    for(ITYPE i = 0; i < ts_aux.size(); i++) source_tSeries[i] = float2cpfp(ts_aux[i]);


    // Prepare data
	ITYPE windowSize = atoi(argv[3]);
	ITYPE exclusionZone = windowSize / 4;
	ITYPE profileLength = timeSeriesLength - windowSize + 1;

	  // Display info through console
	  std::cout << std::endl;
	  std::cout << "------------------------------------------------------------" << std::endl;
	  std::cout << "************************** INFO ****************************" << std::endl;
	  std::cout << std::endl;
	  std::cout << " Time series length: " << timeSeriesLength << std::endl;
	  std::cout << " Window size:        " << windowSize       << std::endl;
	  std::cout << " Exclusion zone:     " << exclusionZone    << std::endl;
	  std::cout << " Profile length:     " << timeSeriesLength << std::endl;
	  std::cout << "------------------------------------------------------------" << std::endl;
	  std::cout << std::endl;

    preprocess(ts_aux, source_means, source_norms, source_df, source_dg, profileLength, windowSize);

    //end of data preparation

    // Initialize profiles
    for (ITYPE i = 0; i < dataSize; i++) {
        source_sw_profile[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
        source_sw_profileIndex[i] = 0;
        source_hw_profile[i] = float2cpfp(-std::numeric_limits<DTYPE>::infinity());
        source_hw_profileIndex[i] = 0;
    }

	std::chrono::duration<double> host_time(0);

    //Compute host if debug enabled
    if(debug)
    {
		std::cout << "[HOST] Computing SCAMP..." << std::endl;
		auto host_start = std::chrono::high_resolution_clock::now();

		//scamp_host(source_tSeries, source_means, source_norms,
			//source_df, source_dg, source_sw_profile, source_sw_profileIndex,
		//	profileLength, exclusionZone, windowSize);
		 //cambiar a steady clock
		auto host_end = std::chrono::high_resolution_clock::now();
		host_time = std::chrono::duration<double>(host_end - host_start);

		std::cout << "[HOST] DONE. Execution time: " << host_time.count() << " seconds." << std::endl;
    }
    double kernel_time_in_sec = 0;
    bool match = true;

    kernel_time_in_sec = run_krnls(context,
                                  q,
                                  kernels,
                                  source_tSeries,
                                  source_means,
								  source_norms,
								  source_df,
								  source_dg,
                                  source_hw_profile,
								  source_hw_profileIndex,
                                  bank,
                                  dataSize,
								  profileLength,
								  exclusionZone,
								  windowSize);

    std::cout << "[FPGA] DONE. Execution time: " << kernel_time_in_sec << " seconds." << std::endl;


    if (debug)
    {
    	match = verify(source_sw_profile, source_hw_profile, source_sw_profileIndex, source_hw_profileIndex ,dataSize);
        std::cout << "[INFO] Speedup FPGA VS HOST: " <<  host_time.count() / kernel_time_in_sec << "x" << std::endl;
        std::cout << (match ? "[INFO] TEST PASSED" : "TEST FAILED") << std::endl;
    }

    std::stringstream outfilename_num;
    outfilename_num << windowSize;
    std::string outfilenamenum = outfilename_num.str();
    std::string outfilename = "SCAMP_MatrixProfile_and_Index_" + outfilenamenum + "_" + argv[2];

    std::fstream profileOutFile(outfilename.c_str(), std::ios_base::out);

    for (ITYPE i = 0; i < timeSeriesLength - windowSize + 1; i++)
    {
      profileOutFile << std::setprecision(std::numeric_limits<DTYPE>::digits10 + 2) << sqrt(2*windowSize * (1-source_hw_profile[i])) << " " << std::setprecision(std::numeric_limits<int>::digits10 + 1) << source_hw_profileIndex[i] << std::endl;
    }

    profileOutFile.close();

    return (match ? EXIT_SUCCESS : EXIT_FAILURE);
}



